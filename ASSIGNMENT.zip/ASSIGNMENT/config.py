from flask import Flask

app = Flask(__name__)

class Config:
    SECRET_KEY = 'your_secret_key'
    MONGO_URI = 'mongodb://localhost:27017/contactApp'
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'your_email@gmail.com'
    MAIL_PASSWORD = 'your_email_password'
    app.config["MAIL_DEFAULT_SENDER"] = "your_email@gmail.com"