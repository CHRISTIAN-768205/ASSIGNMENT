from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_pymongo import PyMongo
from flask_mail import Mail, Message
from bson.objectid import ObjectId
import bcrypt
from itsdangerous import URLSafeTimedSerializer
from flask_cors import CORS
from datetime import timedelta
import os

app = Flask(__name__)
CORS(app)  # Allow requests from your frontend

# Configuration (you can also put these in a separate Config class or file)
app.secret_key = 'your-secret-key'  # Replace with your secret key
app.config['MONGO_URI'] = "mongodb://localhost:27017/healthAppDB"

# Flask-Mail configuration (using Gmail as an example)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'your_email@gmail.com'
app.config['MAIL_PASSWORD'] = 'your_email_password'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

# JWT settings (if needed later)
app.config["JWT_SECRET_KEY"] = "your_jwt_secret_key"  # Use a strong key
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=1)

# Initialize extensions
mongo = PyMongo(app)
mail = Mail(app)

# --------------------------------------------------
# Helper functions for password reset tokens
# --------------------------------------------------

def generate_reset_token(email):
    """Generate a secure token for the given email."""
    s = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    return s.dumps(email, salt='password-reset')

def verify_reset_token(token, expiration=3600):
    """Verify the reset token and return the email if valid."""
    s = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    try:
        email = s.loads(token, salt='password-reset', max_age=expiration)
        return email
    except Exception:
        return None

def send_reset_email(email):
    """Send the password reset email to the specified email address."""
    token = generate_reset_token(email)
    reset_link = f'http://127.0.0.1:5000/reset-password/{token}'
    msg = Message('Password Reset Request',
                  sender=app.config['MAIL_USERNAME'],
                  recipients=[email])
    msg.body = f'''To reset your password, click the link below:
{reset_link}

If you did not request this, please ignore this email.
'''
    mail.send(msg)

# --------------------------------------------------
# Routes
# --------------------------------------------------

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    users = mongo.db.users
    login_user = users.find_one({'username': request.form['username']})
    
    if login_user and bcrypt.checkpw(request.form['password'].encode('utf-8'), login_user['password']):
        session['username'] = request.form['username']
        return redirect(url_for('dashboard'))
    
    flash('Invalid username or password')
    return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        users = mongo.db.users
        existing_user = users.find_one({'username': request.form['username']})
        
        if existing_user is None:
            hashed_pw = bcrypt.hashpw(request.form['password'].encode('utf-8'), bcrypt.gensalt())
            users.insert_one({
                'username': request.form['username'],
                'email': request.form['email'],
                'password': hashed_pw
            })
            flash('Registration successful! Please log in.')
            return redirect(url_for('index'))
        
        flash('Username already exists')
    return render_template('register.html')

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        users = mongo.db.users
        email = request.form['email']
        user = users.find_one({'email': email})
        
        if user:
            send_reset_email(email)
            flash('Password reset link sent to your email')
        else:
            flash('Email not found')
    return render_template('forgot_password.html')

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    email = verify_reset_token(token)
    if not email:
        flash('Invalid or expired token', 'danger')
        return redirect(url_for('forgot_password'))

    if request.method == 'POST':
        new_password = request.form['password']
        users = mongo.db.users
        hashed_pw = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())
        users.update_one({"email": email}, {"$set": {"password": hashed_pw}})
        flash('Your password has been updated!', 'success')
        return redirect(url_for('login'))

    return render_template('reset_password.html')

@app.route('/activate', methods=['GET', 'POST'])
def activate():
    if request.method == 'POST':
        users = mongo.db.users
        email = request.form['email']
        user = users.find_one({"email": email})
        if user:
            send_reset_email(email)
            flash('A password reset link has been sent to your email.', 'info')
        else:
            flash('Email not found. Please check again.', 'warning')
    return render_template('activate.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return render_template('dashboard.html')
    return redirect(url_for('index'))

@app.route('/add-contact', methods=['POST'])
def add_contact():
    if 'username' in session:
        contacts = mongo.db.contacts
        contacts.insert_one({
            'mobile': request.form['mobile'],
            'email': request.form['email'],
            'address': request.form['address'],
            'registration_number': request.form['registration_number']
        })
        flash('Contact added successfully')
        return redirect(url_for('dashboard'))
    return redirect(url_for('index'))

@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        contacts = mongo.db.contacts
        contact = contacts.find_one({'registration_number': request.form['registration_number']})
        return render_template('search_result.html', contact=contact)
    return render_template('search.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

# --------------------------------------------------
# Run the App
# --------------------------------------------------
if __name__ == '__main__':
    app.run(debug=True)
