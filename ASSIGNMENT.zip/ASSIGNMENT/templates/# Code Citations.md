# Code Citations

## License: unknown
https://github.com/Akash280899/Node.js-Login/tree/7e5351f1421dd14931f31bface27ca133784f957/public/reset.html

```
html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <
```

